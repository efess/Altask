﻿using Altask.www.Models;
using System.Collections.Generic;
using System.Data.Entity;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Altask.www.Controllers {
    public partial class TaskController {

    }
}