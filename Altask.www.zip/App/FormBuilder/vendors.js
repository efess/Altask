import 'api-check'; // NOTE: always imported before angular-formly!
import 'angular-formly';
import 'angular-formly-templates-bootstrap';